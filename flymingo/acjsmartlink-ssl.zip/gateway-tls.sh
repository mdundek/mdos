#!/bin/bash

kubectl create -n istio-system secret tls httpbin-credential --key=./privkey.pem --cert=./fullchain.pem

cat <<EOF | k3s kubectl apply -f -
apiVersion: networking.istio.io/v1beta1
kind: Gateway
metadata:
  name: https-gateway-acjsmartlink
  namespace: istio-system
spec:
  selector:
    istio: ingressgateway
  servers:
  - port:
      number: 443
      name: https
      protocol: HTTPS
    hosts:
    - "*.acjsmartlink.net"
    tls:
      mode: SIMPLE
      credentialName: httpbin-credential
EOF
